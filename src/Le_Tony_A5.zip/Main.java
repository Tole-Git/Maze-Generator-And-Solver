public class Main {

    public static void main(String args[]) {
        Maze m = new Maze(20, 20);
        //System.out.println(m.toString());
    }
}
